#include "BaseGame.h"
#include <Windows.h>
#include <gdiplus.h>
#include "Core/InputManager.h"
#include "GameObject.h"

#include "Transform.h"
#include "ImageTexture.h"
#include "MoveComponent.h"
#include "RectLine.h"
#include "Scene.h"

using namespace Gdiplus;

BaseGame::BaseGame()
{
}

BaseGame::~BaseGame()
{
}

void BaseGame::InitGDIPlus()
{
	// GDI+ 초기화 꼭 하기 안하면 안됨
	GdiplusStartupInput gdiplusStartupInput;
	GdiplusStartup(&gdiplusToken, &gdiplusStartupInput, nullptr);

}

void BaseGame::ReleaseGDIPlus()
{
	GdiplusShutdown(gdiplusToken);
}

void BaseGame::Init(HWND p_hwnd)
{
	InitGDIPlus();

	m_Hwnd = p_hwnd;

	m_CurrentScene = new Scene();


}

void BaseGame::AllReset()
{
	InputManager::ResetAllKey();
}

void BaseGame::AllUpdate()
{
	//if (m_GameObject)
	//	m_GameObject->Update();

	if (m_CurrentScene)
		m_CurrentScene->Update();
}

void BaseGame::Render(HDC p_hdc, RECT& p_clientRect)
{
	//if(m_GameObject)
	//	m_GameObject->Render(p_hdc);

	COLORREF m_BGColor = RGB(255, 255, 255);
	// 2. 배경 지우기 (하얀색)
	HBRUSH bg = CreateSolidBrush(m_BGColor);
	FillRect(p_hdc, &p_clientRect, bg);
	DeleteObject(bg);

	if(m_CurrentScene)
		m_CurrentScene->Render(p_hdc);
}

void BaseGame::Test_GameObjectDatas()
{

	//m_CurrentScene->InitSettings();


	GameObject* gameobj = m_CurrentScene->CreateObject("test01");
	gameobj->AddComponent<Transform>();
	gameobj->AddComponent<MoveComponent>();
	gameobj->AddComponent<RectLine>();
	gameobj->AddComponent<ImageTexture>();


	GameObject* gameobj2 = m_CurrentScene->CreateObject("test02");
	gameobj2->AddComponent<Transform>();
	gameobj2->AddComponent<RectLine>();

	gameobj2->GetComponent<Transform>()->m_Position.x = 300;
	gameobj2->GetComponent<Transform>()->m_Position.y = 200;



	//m_GameObject = new GameObject();
	//Transform* transform = m_GameObject->AddComponent<Transform>();
	////ImageTexture* imagetexture = m_GameObject->AddComponent<ImageTexture >("abc");
	//MoveComponent* movecom = m_GameObject->AddComponent<MoveComponent >();

	//// "Resources/img01.jpg"
	//m_GameObject->AddComponent<ImageTexture>(L"C:/InterfaceCPP_Proj/WinAPI_FrameWork_V2/WinAPI_FrameWork_V2/Resources/UVTexture.png");


	//m_GameObject->AddComponent<RectLine>();
}

void BaseGame::UpdateInput(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
	case WM_KEYDOWN:
		InputManager::KeyDown(wParam);
		break;
	case WM_KEYUP:
		InputManager::KeyUp(wParam);
		break;
	case WM_MOUSEMOVE:
		InputManager::MouseMove(lParam);
		break;
	case WM_LBUTTONDOWN:
	case WM_RBUTTONDOWN:
	case WM_MBUTTONDOWN:
		InputManager::MouseDown(message, wParam);
		break;
	case WM_LBUTTONUP:
	case WM_RBUTTONUP:
	case WM_MBUTTONUP:
		InputManager::MouseUp(message, wParam);

		break;
	default:
		break;
	}

		
}


