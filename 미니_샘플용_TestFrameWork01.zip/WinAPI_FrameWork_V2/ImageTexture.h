#pragma once
#include <string>
#include <Windows.h>
#include <gdiplus.h>
#include <vector>
#include "Component.h"
#include "ResourceImageManager.h"

using namespace std;
using namespace Gdiplus;

class ImageTexture : public Component
{
public:
	ImageTexture() 
	{
		m_Image = new Gdiplus::Image(L"Resources/UVTexture.png");
	}
	ImageTexture( wstring p_path ) 
	{
		m_Image = new Gdiplus::Image( p_path.c_str() );
	}

	virtual ~ImageTexture()
	{

	}

public:
	string m_Path = "";
	Gdiplus::Image* m_Image = nullptr;

public:
	void Start() override;
	void Update() override;
	void Render(HDC p_hdc) override;
};

