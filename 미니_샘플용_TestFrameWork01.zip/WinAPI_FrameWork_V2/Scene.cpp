#include "Scene.h"
#include "Core/InputManager.h"
#include "GameObject.h"

#include "Transform.h"
#include "ImageTexture.h"
#include "MoveComponent.h"
#include "RectLine.h"


void Scene::Start()
{
}

void Scene::Update()
{
	for (auto item : m_AllOjects)
	{
		item->Update();
	}
}

void Scene::Render(HDC p_hdc)
{
	for (auto item : m_AllOjects)
	{
		item->Render(p_hdc);
	}
}

GameObject* Scene::CreateObject(const std::string& name)
{
	GameObject* gameobj = new GameObject();

	m_AllOjects.push_back(gameobj);


	return gameobj;
}



void Scene::InitSettings()
{
	GameObject* gameobj =  CreateObject("test");
	gameobj->AddComponent<Transform>();
	gameobj->AddComponent<MoveComponent>();
	gameobj->AddComponent<RectLine>();


	GameObject* gameobj2 = CreateObject("test2");
	gameobj2->AddComponent<Transform>();
	gameobj2->AddComponent<MoveComponent>();
	gameobj2->AddComponent<RectLine>();


}
