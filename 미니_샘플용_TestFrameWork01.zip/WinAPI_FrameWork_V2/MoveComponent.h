#pragma once
#include "Component.h"

class Transform;

class MoveComponent : public Component
{
public:
	MoveComponent() {}

public:
	void Start() override;
	void Update() override;
	//void Render() override;


	void SetMove();


public:
	Transform* TargetTrans;

};

