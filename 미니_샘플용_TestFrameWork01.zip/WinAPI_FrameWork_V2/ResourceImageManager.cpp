#include "ResourceImageManager.h"

//ResourceImageManager* ResourceImageManager::m_Instanceaa = nullptr;

Gdiplus::Image* ResourceImageManager::Load(const std::wstring& path)
{
    auto it = imageMap.find(path);
    if (it != imageMap.end()) return it->second;

    Gdiplus::Image* img = new Gdiplus::Image(path.c_str());
    if (img && img->GetLastStatus() == Gdiplus::Ok) {
        imageMap[path] = img;
        return img;
    }
    delete img;
    return nullptr;
}
