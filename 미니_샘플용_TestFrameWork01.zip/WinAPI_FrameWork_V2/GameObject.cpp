#include "GameObject.h"
#include "Component.h"

void GameObject::Start()
{
}

void GameObject::Update()
{
	for (Component* item : m_AllComponentVec)
	{
		item->Update();
	}

}

void GameObject::Render(HDC p_hdc)
{
	for (Component* item : m_AllComponentVec)
	{
		item->Render(p_hdc);
	}
}
