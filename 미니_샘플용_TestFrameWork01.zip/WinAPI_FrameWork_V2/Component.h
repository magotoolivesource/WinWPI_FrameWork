#pragma once
#include <Windows.h>
#include <gdiplus.h>

class GameObject;

class Component
{
public:
	GameObject* owner = nullptr;

public:
	virtual void Start();
	virtual void Update();
	virtual void Render( HDC p_hdc );
};

