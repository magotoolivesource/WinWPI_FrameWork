#include "ImageTexture.h"

void ImageTexture::Start()
{
	
}

void ImageTexture::Update()
{
}

void ImageTexture::Render(HDC p_hdc)
{
	if (!m_Image)
		return;

	Gdiplus::Graphics graphics(p_hdc);


	int w = m_Image->GetWidth();
	int h = m_Image->GetHeight();

	graphics.DrawImage(m_Image, 0, 0, w, h );


}
