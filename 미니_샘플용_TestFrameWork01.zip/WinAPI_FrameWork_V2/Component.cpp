#include "Component.h"
#include "GameObject.h"

void Component::Start()
{
}

void Component::Update()
{
}

void Component::Render(HDC p_hdc)
{
}
