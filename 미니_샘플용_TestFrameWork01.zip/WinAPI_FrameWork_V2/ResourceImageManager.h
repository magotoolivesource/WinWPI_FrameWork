#pragma once
#include <unordered_map>
#include <string>
#include <Windows.h>
#include <gdiplus.h>
#include "Core/SingletonT.h"

class ResourceImageManager : public SingletonT<ResourceImageManager>
{
//private:
//	static ResourceImageManager* m_Instanceaa;// = nullptr;
//	static ResourceImageManager* Instanceaa()
//	{
//
//	}


private:
	std::unordered_map<std::wstring, Gdiplus::Image*> imageMap;

public:

	Gdiplus::Image* Load(const std::wstring& path);
};

