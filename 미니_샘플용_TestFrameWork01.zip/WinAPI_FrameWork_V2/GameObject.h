#pragma once
#include <Windows.h>
#include <gdiplus.h>
#include <string>
#include <vector>
#include <typeindex>


using namespace std;

class Component;

// 스타
class GameObject
{
protected:
	string Name;
	vector<Component* > m_AllComponentVec;
	
public:
	void Start();
	void Update();
	void Render(HDC p_hdc);



public:
	template <typename T, typename... Args>
	T* AddComponent(Args&&... args );
	template <typename T>
	bool RemoveComponent();

	template <typename T>
	T* GetComponent()
	{
		//std::type_index();

		auto& typemeta = typeid(int);
		size_t tt = typemeta.hash_code();


		T* result = nullptr;
		for (Component* item : m_AllComponentVec)
		{
			result = dynamic_cast<T*>(item);

			if (result)
				return result;
		}

		return nullptr;
	}

	void RegistComponent(Component* p_com)
	{
		m_AllComponentVec.push_back(p_com);
	}

};


template <typename T, typename... Args>
inline T* GameObject::AddComponent(Args && ...args)
{
	// ImageTexture
	T* comp = new T( std::forward<Args>(args)... );
	RegistComponent( comp);

	comp->owner = this;

	return comp;
}

template<typename T>
inline bool GameObject::RemoveComponent()
{
	return false;
}