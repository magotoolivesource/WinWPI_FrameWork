#pragma once
#include "Component.h"
#include "Core/Vector.h"

class Transform : public Component
{
public:
	Vec2 m_Position;

public:
	Transform(){}

public:
	void Start() override;
	void Update() override;
	//void Render() override;

};

