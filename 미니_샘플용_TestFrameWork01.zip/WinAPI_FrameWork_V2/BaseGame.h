#pragma once
#include <Windows.h>


class GameObject;
class Scene;

class BaseGame
{
public:
    BaseGame();
    virtual ~BaseGame();


protected:
    ULONG_PTR gdiplusToken;
    void InitGDIPlus(); // GDI+ 초기화 함수
    void ReleaseGDIPlus(); // GDI+ 해제 함수

public:
    virtual  void Init(HWND p_hwnd);

    virtual void AllReset();
    virtual void AllUpdate();

    virtual void UpdateInput(UINT message, WPARAM wParam, LPARAM lParam);
    virtual void Render(HDC p_hdc, RECT& p_clientRect);

public:
	void Test_GameObjectDatas();

protected:

    HWND m_Hwnd = nullptr;


    //GameObject* m_GameObject = nullptr;
    //vector<GameObject*> m_AllGameObject;

    //// 씬

    Scene* m_CurrentScene = nullptr;
};

