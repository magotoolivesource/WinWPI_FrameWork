#pragma once
#include <Windows.h>
#include <gdiplus.h>
#include <vector>
#include <memory>
#include <string>
#include <algorithm>

#include "GameObject.h"

class Scene
{
public:
	void Start();
	void Update();
	void Render(HDC p_hdc);

	GameObject* CreateObject( const std::string& name );

protected:
	std::vector<GameObject*> m_AllOjects;



public:
	void InitSettings();

};

