#include "RectLine.h"
#include "framebasecomponent.h"

void RectLine::Start()
{
}

void RectLine::Update()
{
}

void RectLine::Render(HDC hdc)
{
	Gdiplus::Graphics graphics(hdc);
    //graphics.ResetTransform();

	Gdiplus::Pen pen(color, thickness);

    Gdiplus::RectF temprect = rect;
    temprect.X += owner->GetComponent<Transform>()->m_Position.x;
    temprect.Y += owner->GetComponent<Transform>()->m_Position.y;
	graphics.DrawRectangle(&pen, temprect);



        
    //HPEN pen = CreatePen(PS_SOLID, thickness, color.GetValue());
    //HBRUSH brush = CreateSolidBrush(RGB(0, 255, 0));
    //SelectObject(hdc, pen);
    ////SelectObject(hdc, brush);

    //Transform* trans = owner->GetComponent<Transform>();
    //int posx = rect.X + trans->m_Position.x;
    //int posy = rect.Y + trans->m_Position.y;
    //int width = rect.Width + trans->m_Position.x;
    //int height = rect.Height + trans->m_Position.y;

    //Rectangle(hdc, posx, posy, width, height);

    ////DeleteObject(brush);
    //DeleteObject(pen);


}
