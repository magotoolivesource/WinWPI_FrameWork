#pragma once
#include <string>
#include <Windows.h>
#include <gdiplus.h>
#include <vector>
#include "Component.h"

using namespace std;
class RectLine : public Component
{
public:
	RectLine()
	{

	}
	virtual ~RectLine()
	{

	}

public:
	void Start() override;
	void Update() override;
	void Render(HDC p_hdc) override;


public:
	Gdiplus::RectF rect = Gdiplus::RectF(0, 0, 100, 100);
	Gdiplus::Color color = Gdiplus::Color(255, 0, 255, 255);
	float thickness = 1.f;
};

