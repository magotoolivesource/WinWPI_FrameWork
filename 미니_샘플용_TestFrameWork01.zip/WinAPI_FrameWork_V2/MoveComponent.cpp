#include "MoveComponent.h"
#include "Core/InputManager.h"
#include <Windows.h>
#include "GameObject.h"
#include "Transform.h"
#include "ImageTexture.h"


void MoveComponent::Start()
{
}

void MoveComponent::Update()
{
	if ( InputManager::ISKeyDown(InputKey::A) )
	{
		OutputDebugStringA("A Press\n");

		Transform* trans = this->owner->GetComponent<Transform>();

		trans->m_Position.x -= 1.0f;
	}


	if (InputManager::ISKeyDown(InputKey::D))
	{
		OutputDebugStringA("D Press\n");

		Transform* trans = this->owner->GetComponent<Transform>();

		trans->m_Position.x += 1.0f;
	}



}

void MoveComponent::SetMove()
{
}
