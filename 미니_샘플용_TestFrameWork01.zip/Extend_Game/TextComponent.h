#pragma once
#include <windows.h>
#include <gdiplus.h>
#include <string>
#include "Component.h"

class TextComponent : public Component
{
public:
	TextComponent()
	{
		family = new Gdiplus::FontFamily(L"Arial");
		font = new Gdiplus::Font(family, 30, Gdiplus::FontStyleRegular, Gdiplus::UnitPixel);
	}

	virtual ~TextComponent()
	{
		delete font;
		delete family;
	}

public:
	virtual void Start() override;
	virtual void Update() override;
	virtual void Render(HDC p_hdc)  override;

public:
	const std::wstring& GetTextW() const { return m_TextW; }
	void SetTextW(const std::wstring& text) { m_TextW = text; }


protected:
	std::wstring m_TextW = L"";

	Gdiplus::FontFamily* family;
	Gdiplus::Font* font;
	Gdiplus::Color color = Gdiplus::Color(255, 255, 0, 255);
};

