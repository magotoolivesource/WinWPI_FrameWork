#include "TextComponent.h"
#include "GameObject.h"
#include "Transform.h"

void TextComponent::Start()
{
}

void TextComponent::Update()
{
}

void TextComponent::Render(HDC p_hdc)
{
	Gdiplus::Graphics graphics(p_hdc);



	Gdiplus::SolidBrush brush(color);
	//Gdiplus::Pen pen(color, FontSize);
	//graphics.DrawRectangle(&pen, rect);

	Gdiplus::StringAlignment hAlign = Gdiplus::StringAlignmentNear;
	Gdiplus::StringAlignment vAlign = Gdiplus::StringAlignmentNear;

	Gdiplus::StringFormat format;
	format.SetAlignment(hAlign);
	format.SetLineAlignment(vAlign);
	//

	Transform* trans = owner->GetComponent<Transform>();
	Gdiplus::PointF point(trans->m_Position.x, trans->m_Position.y);

	graphics.DrawString(m_TextW.c_str(), -1, font, point, &brush);
}
